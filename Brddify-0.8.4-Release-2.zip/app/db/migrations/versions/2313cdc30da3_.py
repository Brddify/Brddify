"""empty message

Revision ID: 2313cdc30da3
Revises: 305943d779c4, 07f9bbb3db4e
Create Date: 2024-07-12 16:18:15.012072

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '2313cdc30da3'
down_revision = ('305943d779c4', '07f9bbb3db4e')
branch_labels = None
depends_on = None


def upgrade() -> None:
    pass


def downgrade() -> None:
    pass

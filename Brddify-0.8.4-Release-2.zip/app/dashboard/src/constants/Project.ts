export const REPO_URL = "https://github.com/Gozargah/Brddify";
export const ORGANIZATION_URL = "https://github.com/Gozargah";
export const DONATION_URL = "https://github.com/Gozargah/Brddify#donation";
